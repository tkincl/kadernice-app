"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAppStore } from "@/store/useAppStore"

function getInitials(jmeno: string) {
  return jmeno
    .split(" ")
    .map((s) => s[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)
}

const BARVY = [
  "bg-blue-100 text-blue-700",
  "bg-emerald-100 text-emerald-700",
  "bg-pink-100 text-pink-700",
  "bg-amber-100 text-amber-700",
  "bg-purple-100 text-purple-700",
]

function getBarvuPodleId(id: string) {
  const index = parseInt(id) % BARVY.length
  return BARVY[index] ?? BARVY[0]
}

export default function KlientkyPage() {
  const router = useRouter()
  const { klientky } = useAppStore()
  const [hledani, setHledani] = useState("")
  const [showNova, setShowNova] = useState(false)
  const [noveJmeno, setNoveJmeno] = useState("")
  const [noveTelefon, setNoveTelefon] = useState("")
  const { pridatKlientku } = useAppStore()

  const filtrovane = klientky.filter(
    (k) =>
      k.jmeno.toLowerCase().includes(hledani.toLowerCase()) ||
      k.telefon.includes(hledani)
  )

  const posledniNavsteva = (id: string) => {
    const k = klientky.find((k) => k.id === id)
    if (!k || k.navstevy.length === 0) return null
    return k.navstevy.sort((a, b) => b.datum.localeCompare(a.datum))[0]
  }

  const handlePridat = () => {
    if (!noveJmeno.trim()) return
    const id = pridatKlientku({
      jmeno: noveJmeno.trim(),
      telefon: noveTelefon.trim(),
      fotkyVlasu: [],
    })
    setShowNova(false)
    setNoveJmeno("")
    setNoveTelefon("")
    router.push(`/klientky/${id}`)
  }

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="flex-shrink-0 px-4 pt-5 pb-3 border-b border-gray-100">
        <h1 className="text-xl font-medium text-gray-900 mb-3">Klientky</h1>
        <div className="flex items-center gap-2 bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5">
          <svg width="16" height="16" fill="none" stroke="#9ca3af" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <input
            type="text"
            placeholder="Hledat jméno nebo telefon..."
            value={hledani}
            onChange={(e) => setHledani(e.target.value)}
            className="flex-1 bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none"
          />
        </div>
      </div>

      {/* Seznam */}
      <div className="flex-1 overflow-y-auto">
        {filtrovane.length === 0 && (
          <p className="text-center text-sm text-gray-400 mt-10">
            Žádná klientka nenalezena
          </p>
        )}
        {filtrovane.map((k) => {
          const posl = posledniNavsteva(k.id)
          return (
            <button
              key={k.id}
              onClick={() => router.push(`/klientky/${k.id}`)}
              className="w-full flex items-center gap-3 px-4 py-3 border-b border-gray-50 active:bg-gray-50 transition-colors text-left"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 ${getBarvuPodleId(k.id)}`}>
                {getInitials(k.jmeno)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{k.jmeno}</p>
                <p className="text-xs text-gray-400">
                  {posl
                    ? `${posl.sluzba} · ${new Date(posl.datum).toLocaleDateString("cs-CZ", { day: "numeric", month: "numeric" })}`
                    : "Nová klientka"}
                </p>
              </div>
              <svg width="16" height="16" fill="none" stroke="#d1d5db" strokeWidth="2" viewBox="0 0 24 24">
                <path d="m9 18 6-6-6-6" />
              </svg>
            </button>
          )
        })}
      </div>

      {/* FAB */}
      <div className="flex-shrink-0 px-4 py-3 border-t border-gray-100 bg-white">
        <button
          onClick={() => setShowNova(true)}
          className="w-full bg-emerald-500 text-white rounded-xl py-3.5 text-sm font-medium flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
        >
          <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M12 5v14M5 12h14" />
          </svg>
          Přidat klientku
        </button>
      </div>

      {/* Modal nová klientka */}
      {showNova && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-end max-w-md mx-auto">
          <div className="bg-white rounded-t-2xl w-full p-5">
            <div className="w-9 h-1 bg-gray-200 rounded-full mx-auto mb-4" />
            <h2 className="text-base font-medium text-gray-900 mb-1">Nová klientka</h2>
            <p className="text-xs text-gray-400 mb-4">Stačí jméno, ostatní doplníš později</p>
            <div className="flex flex-col gap-3 mb-4">
              <div>
                <label className="text-xs font-medium text-gray-400 uppercase tracking-wide block mb-1">Jméno *</label>
                <input
                  autoFocus
                  type="text"
                  placeholder="Jana Nováková"
                  value={noveJmeno}
                  onChange={(e) => setNoveJmeno(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5 text-sm text-gray-900 outline-none focus:border-emerald-300"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-400 uppercase tracking-wide block mb-1">Telefon</label>
                <input
                  type="tel"
                  placeholder="777 123 456"
                  value={noveTelefon}
                  onChange={(e) => setNoveTelefon(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5 text-sm text-gray-900 outline-none focus:border-emerald-300"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowNova(false)}
                className="flex-1 bg-gray-50 border border-gray-100 text-gray-600 rounded-xl py-3 text-sm font-medium"
              >
                Zrušit
              </button>
              <button
                onClick={handlePridat}
                disabled={!noveJmeno.trim()}
                className="flex-1 bg-emerald-500 text-white rounded-xl py-3 text-sm font-medium disabled:opacity-40"
              >
                Vytvořit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
